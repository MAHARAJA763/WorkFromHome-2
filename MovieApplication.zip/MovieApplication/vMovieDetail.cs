﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApplication
{
    class vMovieDetail
    {
        public string MovieName { get; set; }
        public string ActorName { get; set; }
    }
}
