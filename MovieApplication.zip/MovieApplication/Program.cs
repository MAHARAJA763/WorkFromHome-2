﻿using System;
using System.Data.SqlClient;

namespace MovieApplication
{
    class Program
    {
        int choice;

        string connString = "Data Source=PRATIKPC\\SQLEXPRESS;Initial Catalog=ProblemDb;Integrated Security=true";
        SqlDataReader reader;
        SqlCommand command;
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        public void Start()
        {
            Start start = new Start();
            Console.WriteLine("What do you want to do");
            Console.WriteLine("1.Add or Delete Movies \n 2.Add or Delete Actors \n 3.View All Movies 4.Exit");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    start.MovieEdit();
                    Start();
                    break;

                case 2:
                    start.ActorEdit();
                    Start();
                    break;

                case 3:
                    start.ViewAllMovies();
                    break;


                case 4:
                    Environment.Exit(-1);
                    break;

                default:
                    Console.WriteLine("Invalid choice");
                    Start();
                    break;
            }
        }

        

        
        
    }

    

   

   
}
