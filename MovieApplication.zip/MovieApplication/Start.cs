﻿using Assignment1;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApplication
{
    class Start:BaseContext
    {
        private Movie Movie = new Movie();
        private Actor Actor = new Actor();
        public void MovieEdit()
        {
            int choice;
            Program program = new Program();
            
            Console.WriteLine("1.Add Movies \n 2.Delete Movie \n 3.Back");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    AddMovie();
                    MovieEdit();
                    break;

                case 2:
                    Console.WriteLine("enter MovieId to delete");
                    Movie.MovieId = Convert.ToInt32(Console.ReadLine());
                    DeleteMovie();
                    MovieEdit();
                    break;

                case 3:
                    program.Start();
                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    MovieEdit();
                    break;
            }
        }
         void AddMovie()
        {
            Console.WriteLine("Enter Movie Name");
            Movie.MovieName = Console.ReadLine();

            ExecuteNonQuery($"insert into Movies(MovieName)values('{Movie.MovieName}')");
            CloseConnection();
        }
         void DeleteMovie()
        {
            ExecuteNonQuery($"delete from Movies where MovieId = {Movie.MovieId}");
            CloseConnection();
        }

        public void ActorEdit()
        {
            int choice;
            Program program = new Program();
            Console.WriteLine("1.Add Actor \n 2.Delete Actor \n 3.Back");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    AddActor();
                    ActorEdit();
                    break;

                case 2:
                    Console.WriteLine("enter Actorchoice to delete");
                    Actor.ActorId = Convert.ToInt32(Console.ReadLine());
                    DeleteActor();

                    ActorEdit();
                    break;

                case 3:
                    program.Start();
                    break;
            }
        }
        public void AddActor()
        {
            Console.WriteLine("Enter Actor Name");
            Actor.ActorName = Console.ReadLine();
            ExecuteNonQuery($"insert into Actors(ActorName)values('{Actor.ActorName}')");
            CloseConnection();
        }
        public void DeleteActor()
        {
            ExecuteNonQuery($"delete from Actors where ActorId = {Actor.ActorId}");
        }
        public void ViewAllMovies()
        {
            List<vMovieDetail> vMovieDetails = new List<vMovieDetail>();
            var reader = GetReader("select * from vMovies");
            while (reader.Read())
            {
                vMovieDetail vMovieDetail = new vMovieDetail();
                vMovieDetail.MovieName = reader.GetString(0);
                vMovieDetail.ActorName = reader.GetString(1);
                vMovieDetails.Add(vMovieDetail);
            }
            foreach(var movie in vMovieDetails)
            {
                Console.WriteLine($"Movie Name:{movie.MovieName} \t Actor Name:{movie.ActorName}");
            }
        }
    }
}
