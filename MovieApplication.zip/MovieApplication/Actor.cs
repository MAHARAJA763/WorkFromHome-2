﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApplication
{
    public class Actor
    {
        public int ActorId { get; set; }
        public string ActorName { get; set; }
    }
}
