﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApplication
{
    public class MovieDetail
    {
        public int MovieActorId { get; set; }
        public int ActorId { get; set; }
        public int MovieId { get; set; }
    }
}
